package com.jph.u_share.util;

/**
 * Created by penn on 16/10/11.
 */

public class Constants {

    public static final String KEY_WEIXIN="wx3b88e890abe41fce";
    public static final String SECRET_WEIXIN="0dde0a5a5efeb080b086f3f969f386bc";
    public static final String KEY_WEIBO="3114976530";
    public static final String SECRET_WEIBO="40a599d4fa35b733e3562f19241eabe9";
    public static final String KEY_QQ="1105745872";
    public static final String SECRET_QQ="KXOXABjlHrqrJD3z";

    public static final int RC_REQUEST_PERMISSIONS=6006;

}
