
export default function TimeSpan(showText,searchText){
    this.showText=showText;
    this.searchText=searchText;
}