exports.redis = {
  port: 6379
};

exports.github = {
  request_token_url: "https://github.com/login/oauth/access_token",
  client_id: "22100039168eab0a9b97",
  client_secret: "7ffb0455978bcf403b8874d7d43d2f03365591a7"
};

exports.keys = ["jokcy github nextjs app"];
