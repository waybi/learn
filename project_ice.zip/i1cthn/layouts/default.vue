<template lang="pug">
  #app
    #main
      nuxt
    v-nav
</template>

<script>
import vNav from '~components/nav.vue'

export default {
  components: {
    vNav
  }
}
</script>
