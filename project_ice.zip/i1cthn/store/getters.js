export default {
  imageCDN: state => state.imageCDN,
  payments: state => state.payments
  // baseUrl: state => state.baseUrl,
  // user: state => state.user
  // homePageScroll: state => state.homePageScroll,
  // shoppingScroll: state => state.shoppingScroll,
  // houses: state => state.houses,
  // characters: state => state.characters,
  // focusHouse: state => state.focusHouse,
  // focusCharacter: state => state.focusCharacter
}
