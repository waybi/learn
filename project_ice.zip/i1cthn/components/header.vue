<template lang="pug">
header
  .menu
    span.material-icon menu

</template>

<style lang='sass', scopt>
header
  height: 56px
  width: 100%
  box-shadow: 0 0 4px rgba(0,0,0,.14), 0 4px 8px rgba(0,0,0,.28)
  background-color: #2196F3
  color: #fff
  display: flex
  align-items: center

  .menu
    cursor: pointer
    margin-left: 20px
    font-size: 25px
</style>
